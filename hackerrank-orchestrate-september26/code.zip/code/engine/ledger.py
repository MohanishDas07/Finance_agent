from datetime import date, timedelta
from typing import List, Dict, Optional, Tuple
from collections import defaultdict
import statistics

from ingestion.models import FinancialEvent, RequestData, FinancialProfile

def resolve_event_chains(events: List[FinancialEvent]) -> List[FinancialEvent]:
    """
    Resolve linked_event_id chains. A later event supersedes an earlier one.
    Returns the set of leaf events (final state).
    """
    # Create mapping of linked_event_id -> event (child)
    # The parent is event.linked_event_id
    superseded_by: Dict[str, str] = {}
    event_dict = {e.event_id: e for e in events}
    
    for e in events:
        if e.linked_event_id:
            superseded_by[e.linked_event_id] = e.event_id
            
    # Keep only events that are not superseded by anything
    final_events = []
    for e in events:
        if e.event_id not in superseded_by:
            final_events.append(e)
            
    return final_events

def detect_and_project_recurrence(
    events: List[FinancialEvent], 
    start_date: date, 
    days_to_project: int = 90
) -> List[FinancialEvent]:
    """
    Detects recurring events from history and projects them 90 days forward.
    """
    # Group by description
    # We only consider settled and scheduled events for recurrence
    valid_events = [e for e in events if e.status in ('settled', 'scheduled')]
    
    groups = defaultdict(list)
    for e in valid_events:
        # For projection, we want to forecast based on the category schedule.
        # But we must separate debits and credits, and flexibilities.
        key = (e.category, e.direction, e.flexibility)
        dt = e.settlement_date if e.direction == 'credit' and e.settlement_date else e.event_date
        if not dt: dt = e.event_date
            
        group_key = key
        groups[group_key].append((dt, e))
        
    projected = []
    end_date = start_date + timedelta(days=days_to_project)
    
    for desc, items in groups.items():
        items.sort(key=lambda x: x[0])
        
        # Need at least 2 occurrences to establish a pattern
        if len(items) >= 2:
            dates = [x[0] for x in items]
            diffs = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
            avg_diff = sum(diffs) / len(diffs)
            cadence_days = None
            cadence_months = None
            # Is it consistent?
            if (max(diffs) - min(diffs)) <= 5:
                if 25 <= avg_diff <= 35:
                    cadence_months = 1
                else:
                    cadence_days = round(avg_diff)
                    
            if cadence_days or cadence_months:
                latest_event = items[-1][1]
                
                if latest_event.direction == 'debit':
                    if latest_event.flexibility == 'fixed':
                        projected_amt = latest_event.amount
                    else:
                        projected_amt = max(i[1].amount for i in items if i[1].amount is not None)
                else: # credit
                    projected_amt = min(i[1].amount for i in items if i[1].amount is not None)
                
                # Project forward
                from dateutil.relativedelta import relativedelta
                if cadence_months:
                    next_date = dates[-1] + relativedelta(months=1)
                else:
                    next_date = dates[-1] + timedelta(days=cadence_days)
                
                while next_date <= end_date:
                    if next_date >= start_date:
                        import dataclasses
                        kwargs = dataclasses.asdict(latest_event)
                        kwargs['event_id'] = f"projected_{latest_event.event_id}_{next_date.strftime('%Y%m%d')}"
                        kwargs['event_date'] = next_date
                        kwargs['settlement_date'] = next_date
                        kwargs['status'] = 'projected'
                        kwargs['amount'] = projected_amt
                        
                        projected.append(FinancialEvent(**kwargs))
                        
                    if cadence_months:
                        next_date += relativedelta(months=1)
                    else:
                        next_date += timedelta(days=cadence_days)
                    
    return projected

def build_ledger(
    events: List[FinancialEvent], 
    request_date: date, 
    profile: FinancialProfile
) -> List[FinancialEvent]:
    """
    Builds the final forward-looking 90-day ledger for a user.
    """
    # 1. Resolve chains
    resolved = resolve_event_chains(events)
    
    # 2. Filter out cancelled, failed, unrealized
    valid_statuses = ('settled', 'scheduled', 'pending', 'confirmed')
    filtered = [e for e in resolved if e.status in valid_statuses]
    
    # 3. Handle pending: 
    # "Reserve pending debits. Exclude pending credits"
    # So we remove pending credits.
    filtered = [e for e in filtered if not (e.status == 'pending' and e.direction == 'credit')]
    
    # 4. Project recurrence
    projected = detect_and_project_recurrence(filtered, request_date)
    
    # Combine real and projected
    all_events = filtered + projected
    
    future_events = []
    for e in all_events:
        dt = e.settlement_date if e.direction == 'credit' and e.settlement_date else e.event_date
        if not dt: dt = e.event_date
        
        # We only deduct events that happen ON OR AFTER request_date.
        # Past pending events are already held in the available balance.
        if dt >= request_date:
            future_events.append(e)
            
    # Sort chronologically
    def get_sort_date(e):
        dt = e.settlement_date if e.direction == 'credit' and e.settlement_date else e.event_date
        if not dt: return e.event_date
        return dt
        
    future_events.sort(key=get_sort_date)
    return future_events
